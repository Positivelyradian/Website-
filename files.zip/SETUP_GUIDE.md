# 🚀 File4Life — Setup & Deployment Guide

Everything you need to go from zero to a live, revenue-earning file conversion website.

---

## What you have

| File | What it does |
|---|---|
| `server.js` | The backend — handles all file conversions |
| `package.json` | Node.js dependencies list |
| `converter.html` | The working conversion page (plug into your frontend) |
| `file4life.html` | Your original landing page |

---

## Step 1 — Install on your computer (to test locally)

You need **Node.js** (free). Download from https://nodejs.org (get the LTS version).

Then open a terminal in the `file4life-backend` folder and run:

```bash
npm install
```

This installs all the JavaScript packages automatically.

---

## Step 2 — Install system tools (for full conversion support)

These are free tools that do the actual converting work.

### Mac
```bash
brew install ffmpeg          # video + audio conversions
brew install poppler         # PDF → text
brew install libreoffice     # document conversions (Word, PDF etc)
```

### Ubuntu / Debian Linux (great for servers)
```bash
sudo apt update
sudo apt install ffmpeg poppler-utils libreoffice -y
```

### Windows
- FFmpeg: https://ffmpeg.org/download.html (add to PATH)
- LibreOffice: https://libreoffice.org/download
- Poppler: https://github.com/oschwartz10612/poppler-windows/releases

---

## Step 3 — Run the backend locally

```bash
node server.js
```

You'll see: `✅ File4Life backend running → http://localhost:3001`

Open `converter.html` in your browser — it will talk to the backend automatically.

**Test it:** Drop a JPG, select PNG, click Convert. If it works, you're ready to deploy.

---

## Step 4 — Deploy to the internet (choose one)

### Option A — Railway (easiest, ~$5/month, recommended)
1. Go to https://railway.app and sign up
2. Click "New Project" → "Deploy from GitHub"
3. Push your `file4life-backend` folder to a GitHub repo
4. Railway auto-detects Node.js and deploys it
5. You get a URL like `https://file4life-backend.railway.app`
6. In `converter.html`, change `API_BASE` to that URL

### Option B — Render (free tier available)
1. Go to https://render.com
2. Connect GitHub, select your repo
3. Build command: `npm install`
4. Start command: `node server.js`
5. Free tier sleeps after inactivity — paid plan ($7/mo) keeps it awake

### Option C — DigitalOcean Droplet (~$6/month, most control)
1. Create a $6/month Ubuntu droplet
2. SSH in, install Node + ffmpeg + LibreOffice (see Step 2)
3. Copy your files up via `scp` or GitHub
4. Run with PM2 (keeps it alive):
   ```bash
   npm install -g pm2
   pm2 start server.js --name file4life
   pm2 save
   ```
5. Point your domain to the droplet IP (Cloudflare DNS recommended)

---

## Step 5 — Host your frontend (HTML files)

Your HTML files (the landing page + converter) are just static files — they don't need a server.

**Best free option: Netlify**
1. Go to https://netlify.com
2. Drag and drop your HTML files into the dashboard
3. You get a free URL like `https://file4life.netlify.app`
4. Connect your custom domain (file4life.com etc) — Netlify handles SSL for free

---

## Step 6 — Connect frontend to backend

In `converter.html`, find this line near the top of the `<script>`:

```js
const API_BASE = 'http://localhost:3001';
```

Change it to your deployed backend URL:

```js
const API_BASE = 'https://your-backend.railway.app';
```

---

## Step 7 — Earn money with Google AdSense

AdSense pays you when visitors see or click ads on your site.

### How to apply
1. Go to https://adsense.google.com
2. Sign in with your Google account
3. Add your website URL
4. Google reviews it (takes 1–14 days)
5. Once approved, you get a **Publisher ID** like `ca-pub-1234567890123456`

### Add ads to converter.html

Find the three `<!-- Replace with your AdSense code -->` comments in `converter.html`.
Replace each one with:

```html
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-YOUR-ID-HERE"
     data-ad-slot="YOUR-AD-SLOT-ID"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
```

Also add this once in the `<head>` of every page:
```html
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-YOUR-ID-HERE" crossorigin="anonymous"></script>
```

### AdSense requirements (to get approved)
- Your site must have real, useful content (yours does ✅)
- Must have a Privacy Policy page (add one — free generator at https://privacypolicygenerator.info)
- Must have a Terms of Service page
- Needs some traffic — even 20-50 daily visitors helps

### Revenue expectations
- 1,000 visitors/day → roughly $1–5/day depending on your audience
- File conversion sites do well because people search for them on Google

---

## Step 8 — Get traffic from Google (SEO)

Add this to the `<head>` of your `file4life.html`:

```html
<meta name="description" content="Free online file converter. Convert images, documents, audio and video. No sign-up required. Files deleted in 1 hour.">
```

Create specific pages for popular searches, e.g.:
- `/jpg-to-png` — "Convert JPG to PNG free online"
- `/pdf-to-word` — "Convert PDF to Word free"
- `/mp4-to-mp3` — "Extract audio from video free"

Each of these can rank on Google and bring free traffic → more ad revenue.

---

## API endpoints reference

| Method | URL | What it does |
|---|---|---|
| `POST` | `/api/convert` | Convert a single file |
| `POST` | `/api/convert/batch` | Convert up to 10 files |
| `GET` | `/api/formats` | List all supported formats |
| `GET` | `/api/health` | Check if server is running |
| `GET` | `/download/:jobId/:filename` | Download converted file |

---

## Supported conversions

| Type | Input formats | Output formats |
|---|---|---|
| Images | JPG, PNG, WEBP, GIF, AVIF, BMP, TIFF | JPG, PNG, WEBP, AVIF, GIF, BMP, TIFF |
| Audio | MP3, WAV, FLAC, OGG, AAC, M4A | MP3, WAV, FLAC, OGG, AAC, M4A |
| Video | MP4, MOV, AVI, WEBM, MKV | MP4, WEBM, AVI, MOV, MKV, GIF |
| Documents | PDF, DOCX, DOC, TXT, HTML | PDF, DOCX, TXT |
| Archives | Any file | ZIP |

---

## Adding a Pro paid plan later (optional)

The backend already has a Stripe stub at the bottom of `server.js`.
When you're ready:
1. Sign up at https://stripe.com
2. Uncomment the Stripe section in `server.js`
3. Add your Stripe secret key as an environment variable: `STRIPE_SECRET_KEY=sk_live_...`
4. Add a "Go Pro" button to your frontend

Pro features you could charge for:
- Files up to 2GB (free: 500MB)
- Batch convert 50 files at once
- Priority processing
- No ads

---

## Summary checklist

- [ ] Run `npm install` in the backend folder
- [ ] Install ffmpeg and LibreOffice on your server
- [ ] Test locally with `node server.js`
- [ ] Deploy backend to Railway/Render/DigitalOcean
- [ ] Deploy frontend to Netlify
- [ ] Update `API_BASE` in `converter.html`
- [ ] Apply for Google AdSense
- [ ] Add Privacy Policy and Terms pages
- [ ] Add AdSense code once approved
- [ ] Create SEO landing pages for popular conversions

You're good to go. Any questions — you know where to find help.
